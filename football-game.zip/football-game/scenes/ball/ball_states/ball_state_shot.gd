class_name BallStateShot
extends BallState

const DURATION_THROW := 1000
const THROW_HEIGHT := 5
const THROW_SPRITE_SCALE := 0.8

var time_since_thrown := Time.get_ticks_msec()

func _enter_tree() -> void:
	if ball.velocity.y != 0 and ball.velocity.x == 0:
		animation_player.play("vert_roll")
		animation_player.advance(0)
	else:
		animation_player.play("roll")
		animation_player.advance(0)
	sprite.scale.y = THROW_SPRITE_SCALE
	ball.height = THROW_HEIGHT
	time_since_thrown = Time.get_ticks_msec()
	
func _process(delta: float) -> void:
	if Time.get_ticks_msec() - time_since_thrown > DURATION_THROW:
		transition_state(Ball.State.FREEFORM)
	else:
		ball.move_and_collide(ball.velocity * delta)
	
func _exit_tree() -> void:
	sprite.scale.y = 1.0
