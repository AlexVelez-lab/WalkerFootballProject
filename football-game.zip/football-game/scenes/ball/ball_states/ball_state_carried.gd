class_name BallStateCarried
extends BallState

const OFFSET_FROM_PLAYER := Vector2(0, -5)
const SHIFT_INTENSITY := 1.0
const SHIFT_FREQUENCY := 10.0

var dribble_time := 0.0

func _enter_tree() -> void:
	assert(carrier != null)
	GameEvents.ball_possessed.emit(carrier.fullname)
	
func _process(delta: float) -> void:
	var vy := 0.0
	dribble_time += delta

	if carrier.velocity != Vector2.ZERO:
		vy = cos(dribble_time * SHIFT_FREQUENCY) * SHIFT_INTENSITY
		if carrier.heading.x >= 0:
			animation_player.play("roll")
		else:
			animation_player.play_backwards("roll")
	else:
		animation_player.play("idle")
	ball.position = carrier.position + Vector2(carrier.heading.x * OFFSET_FROM_PLAYER.x, OFFSET_FROM_PLAYER.y)
	
func _exit_tree() -> void:
	GameEvents.ball_released.emit()
