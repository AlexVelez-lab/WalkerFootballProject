class_name BallStateFreeform
extends BallState

const MAX_CAPTURE_HEIGHT := 20
const BOUNCINESS := .5

var time_since_freeform := Time.get_ticks_msec()

func _enter_tree() -> void:
	player_detection_area.body_entered.connect(on_player_enter.bind())
	time_since_freeform = Time.get_ticks_msec()

func on_player_enter(body: Player) -> void:
	if ball.height < MAX_CAPTURE_HEIGHT:
		ball.carrier = body
		transition_state(Ball.State.CARRIED)

func _process(delta: float) -> void:
	player_detection_area.monitoring = (Time.get_ticks_msec() - time_since_freeform > state_data.lock_duration)
	if ball.velocity == Vector2.ZERO:
		animation_player.play("idle")
	elif ball.velocity.x != 0:
		animation_player.play("roll")
		animation_player.advance(0)
	ball.move_and_collide(ball.velocity * delta)
	var friction := ball.friction_air if ball.height > 0 else ball.friction_ground
	ball.velocity = ball.velocity.move_toward(Vector2.ZERO, friction * delta)
	process_gravity(delta, BOUNCINESS)
	ball.move_and_collide(ball.velocity * delta)
		
		
