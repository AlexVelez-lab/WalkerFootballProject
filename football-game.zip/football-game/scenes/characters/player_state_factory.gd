class_name PlayerStateFactory

var states : Dictionary

func _init() -> void:
	states = {
		Player.State.MOVING: PlayerStateMoving,
		Player.State.RECOVERING: PlayerStateRecovering,
		Player.State.TACKLING: PlayerStateTackling,
		Player.State.PREPPING_THROW: PlayerStatePreppingThrow,
		Player.State.THROWING: PlayerStateThrowing,
		Player.State.PASSING: PlayerStatePassing,
		Player.State.HURT: PlayerStateHurt,
		Player.State.RESETTING: PlayerStateResetting,
	}
	
func get_fresh_state(state: Player.State) -> PlayerState:
	assert(states.has(state), "state doesnt exist")
	return states.get(state).new()
