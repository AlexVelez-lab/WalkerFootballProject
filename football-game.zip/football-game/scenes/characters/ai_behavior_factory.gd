class_name AIBehaviorFactory

var roles: Dictionary

func _init() -> void:
	roles = {
		Player.Role.OFFENSE: AIBehaviorField,
		Player.Role.DEFENSE: AIBehaviorField,
	}

func get_ai_behavior(role: Player.Role) -> AIBehavior:
	assert(roles.has(role), "role doesnt exist")
	return roles.get(role).new()
