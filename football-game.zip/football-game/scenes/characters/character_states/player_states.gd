class_name PlayerState
extends Node

signal state_transition_requested(new_state: Player.State, state_data: PlayerStateData)

var ai_behavior : AIBehavior = null
var animation_player: AnimationPlayer = null
var ball : Ball = null
var player : Player = null
var state_data : PlayerStateData = PlayerStateData.new()
var teamate_detection_area : Area2D = null
var own_endzone : Goal = null
var target_endzone : Goal = null
var tackle_damage_emitter_area : Area2D = null


func setup(context_player: Player, context_data : PlayerStateData, context_animation_player: AnimationPlayer, context_ball: Ball, context_teamate_detection_area: Area2D, context_own_endzone : Goal, context_target_endzone : Goal, context_tackle_damage_emitter_area: Area2D, context_ai_behavior: AIBehavior) -> void:
	player = context_player
	animation_player = context_animation_player
	state_data = context_data
	ball = context_ball
	teamate_detection_area = context_teamate_detection_area
	own_endzone = context_own_endzone
	target_endzone = context_target_endzone
	ai_behavior = context_ai_behavior
	tackle_damage_emitter_area = context_tackle_damage_emitter_area
	
func transition_state(new_state: Player.State, data: PlayerStateData = PlayerStateData.new()) -> void:
	state_transition_requested.emit(new_state, data)

func on_animation_complete() -> void:
	pass

func can_pass() -> bool:
	return false
