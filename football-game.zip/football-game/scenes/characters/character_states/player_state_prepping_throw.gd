class_name PlayerStatePreppingThrow
extends PlayerState

const DURATION_MAX_BONUS := 1000.0
const EASE_REWARD_FACTOR := 2.0

var throw_direction := Vector2.ZERO
var time_start_shot := Time.get_ticks_msec()

func _enter_tree() -> void:
	animation_player.play("prep_throw")
	player.velocity = Vector2.ZERO
	time_start_shot = Time.get_ticks_msec()
	throw_direction = player.heading

func _process(delta: float) -> void:
	throw_direction += KeyUtils.get_input_vector(player.control_scheme) * delta
	if KeyUtils.is_action_just_released(player.control_scheme, KeyUtils.Action.SHOOT):
		var duration_press := clampf(Time.get_ticks_msec() - time_start_shot, 0.0, DURATION_MAX_BONUS)
		var ease_time := duration_press / DURATION_MAX_BONUS
		var bonus := ease(ease_time, EASE_REWARD_FACTOR)
		var throw_power := player.power * (1 + bonus)
		throw_direction = throw_direction.normalized()
		var state_data := PlayerStateData.new()
		state_data.throw_power = throw_power
		state_data.throw_direction = throw_direction
		#var data = PlayerStateData.build().set_throw_power(throw_power).set_throw_direction(throw_direction)
		transition_state(Player.State.THROWING, state_data)
		
