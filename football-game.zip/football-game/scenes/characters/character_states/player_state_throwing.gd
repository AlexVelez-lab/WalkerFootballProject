class_name PlayerStateThrowing
extends PlayerState

func _enter_tree() -> void:
	animation_player.play("throw")
	
func on_animation_complete() -> void:
	if player.control_scheme == Player.ControlScheme.CPU:
		transition_state(Player.State.RECOVERING)
	else:
		transition_state(Player.State.MOVING)
	throw_ball()
	
func throw_ball() -> void:
	ball.throw(state_data.throw_direction * state_data.throw_power)
