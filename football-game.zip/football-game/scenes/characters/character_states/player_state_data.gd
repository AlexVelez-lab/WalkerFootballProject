class_name PlayerStateData

var tackle_direction : Vector2
var throw_direction : Vector2
var throw_power : float
var pass_target : Player
var reset_position : Vector2

static func build() -> PlayerStateData:
	return PlayerStateData.new()
	
func set_throw_direction(direction: Vector2) -> PlayerStateData:
	throw_direction = direction
	return self
	
func set_throw_power(power: float) -> PlayerStateData:
	throw_power = power
	return self
	
func set_tackle_direction(direction: Vector2) -> PlayerStateData:
	tackle_direction = direction
	return self

func set_pass_target(player: Player) -> PlayerStateData:
	pass_target = player
	return self
	
func set_reset_position(position: Vector2) -> PlayerStateData:
	reset_position = position
	return self
