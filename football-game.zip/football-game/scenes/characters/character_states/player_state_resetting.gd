class_name PlayerStateResetting
extends PlayerState

const DURATION_RESET := 3000

var time_since_reset := Time.get_ticks_msec()

func _enter_tree() -> void:
	time_since_reset = Time.get_ticks_msec()

func _process(_delta: float) -> void:
	animation_player.play("idle")
	if Time.get_ticks_msec() - time_since_reset > DURATION_RESET:
		transition_state(Player.State.MOVING)
