class_name Goal
extends Node2D

@onready var targets = $Targets
@onready var scoring_area := %ScoringArea

var country := ""

func _ready() -> void:
	scoring_area.body_entered.connect(on_ball_enter_scoring_area.bind())
	
func on_ball_enter_scoring_area(_ball:Ball) -> void:
	SoundPlayer.play(SoundPlayer.Sound.WHISTLE)
	GameEvents.team_scored.emit(country)

func initialize(context_country: String) -> void:
	country = context_country
	
func get_center_target_position() -> Vector2:
	return targets.get_child(1).global_position
