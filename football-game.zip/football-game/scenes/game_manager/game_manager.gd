extends Node

const DURATION_GAME := 2 * 60

enum State {IN_PLAY, SCORED, RESET, KICKOFF, OVERTIME, GAMEOVER}

var countries : Array[String] = ["STEELERS", "RAVENS"]
var current_state : GameState = null
var state_factory := GameStateFactory.new()
var score : Array[int] = [0,0]
var time_left : float

func _ready() -> void:
	SoundPlayer.play(SoundPlayer.Sound.NFL)
	time_left = DURATION_GAME
	switch_states(State.IN_PLAY)

func switch_states(state: State, data: GameStateData = GameStateData.new()) -> void:
	if current_state != null:
		current_state.queue_free()
	current_state = state_factory.get_fresh_state(state)
	current_state.setup(self, data)
	current_state.state_transition_requested.connect(switch_states.bind())
	current_state.name = "GameStateMachine: " + str(state)
	call_deferred("add_child", current_state)

func is_game_tied() -> bool:
	return score[0] == score[1]
	
func is_time_up() -> bool:
	return time_left <= 0
	
func get_winner_country() -> String:
	assert(not is_game_tied())
	return countries[0] if score[0] > score[1] else countries[1]

func increase_score(country_scored_on: String) -> void:
	var index_country_scoring := 1 if country_scored_on == countries[0] else 0
	score[index_country_scoring] += 1
	GameEvents.score_changed.emit()

func has_someone_scored() -> bool:
	return score[0] > 0 or score[1] > 0
