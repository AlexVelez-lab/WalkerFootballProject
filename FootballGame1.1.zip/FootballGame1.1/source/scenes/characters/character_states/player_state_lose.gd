class_name PlayerStateLose
extends PlayerState

const GROUND_FRICTION := 90.0

func _process(delta: float) -> void:
	player.velocity = player.velocity.move_toward(Vector2.ZERO, delta * GROUND_FRICTION)

func _enter_tree() -> void:
	animation_player.play("lose")
