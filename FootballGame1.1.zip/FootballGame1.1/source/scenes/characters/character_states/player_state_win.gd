class_name PlayerStateWin
extends PlayerState

const GROUND_FRICTION := 90.0
# Called when the node enters the scene tree for the first time.
func _process(delta: float) -> void:
	player.velocity = player.velocity.move_toward(Vector2.ZERO, delta * GROUND_FRICTION)

func _enter_tree() -> void:
	animation_player.play("win")
