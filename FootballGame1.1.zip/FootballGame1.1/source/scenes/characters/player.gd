class_name Player
extends CharacterBody2D

signal swap_requested(player: Player)

const COUNTRIES := ["DEFAULT", "FRANCE", "RAVENS", "BRAZIL", "ENGLAND", "GERMANY", "ITALY", "SPAIN", "STEELERS"]
const CONTROL_SCHEME_MAP : Dictionary = {
	ControlScheme.CPU: preload("res://assets/art/props/cpu.png"),
	ControlScheme.P1: preload("res://assets/art/props/1p.png"),
	ControlScheme.P2: preload("res://assets/art/props/2p.png"),
}

enum ControlScheme {CPU, P1, P2}
enum Role {OFFENSE, DEFENSE}
enum SkinColor {LIGHT, MEDIUM, DARK}
enum State{MOVING, TACKLING, RECOVERING, PREPPING_THROW, THROWING, PASSING, HURT, RESETTING, WIN, LOSE}


@export var ball: Ball
@export var control_scheme : ControlScheme
@export var power : float
@export var speed : float
@export var own_endzone: Goal
@export var target_endzone: Goal

@onready var control_sprite : Sprite2D = %ControlSprite
@onready var animation_player : AnimationPlayer = %AnimationPlayer
@onready var player_sprite : Sprite2D = %PlayerSprite
@onready var teamate_detection_area : Area2D = %TeamateDetectionArea
@onready var tackle_damage_emitter_area : Area2D = %TackleDamageEmitterArea
@onready var opponent_detection_area : Area2D = %OpponentDetectionArea

var ai_behavior_factory := AIBehaviorFactory.new()
var country := ""
var current_ai_behavior : AIBehavior = null
var current_state: PlayerState = null
var heading := Vector2.RIGHT
var state_factory := PlayerStateFactory.new()
var fullname := ""
var role := Player.Role.OFFENSE
var skin_color := Player.SkinColor.MEDIUM
var spawn_position := Vector2.ZERO
var spawn_heading := Vector2.RIGHT
var weight_on_duty_steering := 0.0

func _ready() -> void:
	set_control_texture()
	setup_ai_behavior()
	switch_state(State.MOVING)
	set_shader_properties()
	tackle_damage_emitter_area.body_entered.connect(on_tackle_player.bind())
	spawn_position = position
	spawn_heading = heading
	GameEvents.team_reset.connect(on_team_reset.bind())
	GameEvents.game_over.connect(on_game_over.bind())

func _process(_delta: float) -> void:
	move_and_slide()
	flip_sprites()
	
func set_shader_properties() -> void:
	player_sprite.material.set_shader_parameter("skin_color", skin_color)
	var country_color := COUNTRIES.find(country)
	country_color = clampi(country_color, 0, COUNTRIES.size() - 1)
	player_sprite.material.set_shader_parameter("team_color", country_color)

func initialize(context_position: Vector2, context_ball: Ball, context_own_endzone: Goal, context_target_endzone: Goal, context_player_data: PlayerResource, context_country: String) -> void:
	position = context_position
	ball = context_ball
	own_endzone = context_own_endzone
	target_endzone = context_target_endzone
	speed = context_player_data.speed
	power = context_player_data.power
	role = context_player_data.role
	skin_color = context_player_data.skin_color
	fullname = context_player_data.full_name
	heading = Vector2.LEFT if target_endzone.position.x < position.x else Vector2.RIGHT
	country = context_country

func setup_ai_behavior() -> void:
	current_ai_behavior = ai_behavior_factory.get_ai_behavior(role)
	current_ai_behavior.setup(self, ball, opponent_detection_area, teamate_detection_area)
	current_ai_behavior.name = "AI Behavior"
	add_child(current_ai_behavior)

func switch_state(state: State, state_data: PlayerStateData = PlayerStateData.new()) -> void:
	if current_state != null:
		current_state.queue_free()
	current_state = state_factory.get_fresh_state(state)
	current_state.setup(self, state_data, animation_player, ball, teamate_detection_area, own_endzone, target_endzone, tackle_damage_emitter_area, current_ai_behavior)
	current_state.state_transition_requested.connect(switch_state.bind())
	current_state.name = "PlayerStateMachine: " + str(state)
	call_deferred("add_child", current_state)
	
func set_movement_animation() -> void:
	if velocity.length() > 0:
		animation_player.play("running")
	else:
		animation_player.play("idle")

func set_heading() -> void:
	if velocity.x >0:
		heading = Vector2.RIGHT
	elif velocity.x < 0:
		heading = Vector2.LEFT

func flip_sprites() -> void:
	if heading == Vector2.RIGHT:
		player_sprite.flip_h = false
		tackle_damage_emitter_area.scale.x = 1
		opponent_detection_area.scale.x = 1
	elif heading == Vector2.LEFT:
		player_sprite.flip_h = true
		tackle_damage_emitter_area.scale.x = -1
		opponent_detection_area.scale.x = -1

func get_hurt(hurt_origin: Vector2) -> void:
	switch_state(Player.State.HURT, PlayerStateData.build().set_tackle_direction(hurt_origin))

func has_ball() -> bool:
	return ball.carrier == self
	
func on_tackle_player(player: Player) -> void:
	if player != self and player.country != country and player == ball.carrier:
		player.get_hurt(position.direction_to(player.position))

func set_control_texture() -> void:
	control_sprite.texture = CONTROL_SCHEME_MAP[control_scheme]
	
func on_animation_complete() -> void:
	if current_state != null:
		current_state.on_animation_complete()
		
func get_pass_request(player: Player) -> void:
	if ball.carrier == self and current_state != null and current_state.can_pass():
		switch_state(Player.State.PASSING, PlayerStateData.build().set_pass_target(player))
		
func on_team_reset() -> void:
	position = spawn_position
	velocity = Vector2.ZERO
	switch_state(State.RESETTING)

func on_game_over(country_winner: String) -> void:
	if country == country_winner:
		switch_state(Player.State.LOSE)
	else:
		switch_state(Player.State.WIN)

func reset_for_new_down(formation_shift: Vector2) -> void:
	# Stop the outgoing state first: on its last frame it could otherwise request a transition
	# (e.g. hurt/recovering finishing) that overrides the hold.
	if current_state != null:
		current_state.set_process(false)
	position = spawn_position + formation_shift
	velocity = Vector2.ZERO
	heading = spawn_heading
	switch_state(State.RESETTING)

func resume_play() -> void:
	switch_state(State.MOVING)
