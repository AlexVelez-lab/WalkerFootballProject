extends Node

signal team_reset
signal team_scored(country_scored_on: String)
signal ball_possessed(player_name: String)
signal ball_released
signal ball_fumbled(yard_line_x: float)
signal tackle_freeze_started
signal new_down(yard_line_x: float)
signal play_resumed
signal down_changed
signal score_changed
signal game_over(country_winner: String)
