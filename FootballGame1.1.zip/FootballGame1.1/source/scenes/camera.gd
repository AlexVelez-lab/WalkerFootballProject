class_name Camera
extends Camera2D

const DISTANCE_TARGET:= 100.0
const SMOOTHING_BALL_CARRIED := 2
const SMOOTHING_BALL_DEFAULT := 8

@export var ball : Ball

func _ready() -> void:
	GameEvents.tackle_freeze_started.connect(on_tackle_freeze_started.bind())
	GameEvents.new_down.connect(on_new_down.bind())

# Disabling processing also halts the camera's smoothing, so the view stays put.
func on_tackle_freeze_started() -> void:
	process_mode = Node.PROCESS_MODE_DISABLED

func on_new_down(_yard_line_x: float) -> void:
	process_mode = Node.PROCESS_MODE_INHERIT

func _process(_delta: float) -> void:
	if ball.carrier != null:
		position = ball.carrier.position + ball.carrier.heading * DISTANCE_TARGET
		position_smoothing_speed = SMOOTHING_BALL_CARRIED
	else:
		position = ball.position
		position_smoothing_speed = SMOOTHING_BALL_DEFAULT
