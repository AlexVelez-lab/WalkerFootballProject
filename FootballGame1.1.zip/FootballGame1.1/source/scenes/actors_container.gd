class_name ActorsContainer
extends Node2D

const DURATION_WEIGHT_CACHE := 200
const FIELD_EDGE_PADDING := 5.0
const PLAYER_PRELOAD := preload("res://scenes/characters/player.tscn")

@export var ball: Ball
@export var endzone_home: Goal
@export var endzone_away: Goal

@onready var spawns : Node2D = %Spawns


var squad_home : Array[Player] = []
var squad_away : Array[Player] = []
var time_since_last_cache_refresh := Time.get_ticks_msec()

func _ready() -> void:
	squad_home = spawn_players(GameManager.countries[0], endzone_home)
	endzone_home.initialize(GameManager.countries[0])
	spawns.scale.x = -1
	squad_away = spawn_players(GameManager.countries[1], endzone_away)
	endzone_away.initialize(GameManager.countries[1])
	
	var player : Player = get_children().filter(func(p): return p is Player)[3]
	player.control_scheme = Player.ControlScheme.P1
	player.set_control_texture()
	GameEvents.tackle_freeze_started.connect(on_tackle_freeze_started.bind())
	GameEvents.new_down.connect(on_new_down.bind())
	GameEvents.play_resumed.connect(on_play_resumed.bind())

func _process(_delta: float) -> void:
	if Time.get_ticks_msec() - time_since_last_cache_refresh > DURATION_WEIGHT_CACHE:
		time_since_last_cache_refresh = Time.get_ticks_msec()
		set_on_duty_weights()
		
func spawn_players(country: String, own_endzone: Goal) -> Array[Player]:
	var player_nodes : Array[Player] = []
	var players := DataLoader.get_squad(country)
	var target_endzone := endzone_home if own_endzone == endzone_away else endzone_away
	for i in players.size():
		var player_position := spawns.get_child(i).global_position as Vector2
		var player_data := players[i] as PlayerResource
		var player := spawn_player(player_position, own_endzone, target_endzone, player_data, country)
		player_nodes.append(player)
		add_child(player)
	return player_nodes
	
func spawn_player(player_position: Vector2, own_endzone: Goal, target_endzone: Goal, player_data: PlayerResource, country: String) -> Player:
	var player : Player = PLAYER_PRELOAD.instantiate()
	player.initialize(player_position, ball, own_endzone, target_endzone, player_data, country)
	player.swap_requested.connect(on_player_swap_request.bind())
	return player

func set_on_duty_weights() -> void:
	for squad in [squad_away, squad_home]:
		var cpu_players : Array[Player] = squad.filter(
			func(p: Player): return p.control_scheme == Player.ControlScheme.CPU
		)
		cpu_players.sort_custom(func(p1: Player, p2: Player):
			return p1.spawn_position.distance_squared_to(ball.position) < p2.spawn_position.distance_squared_to(ball.position))

		for i in range(cpu_players.size()):
			cpu_players[i].weight_on_duty_steering = 1 -ease(float(i)/10, .1)

func on_player_swap_request(requester: Player) -> void:
	var squad := squad_home if requester.country == squad_home[0].country else squad_away
	var cpu_players : Array[Player] = squad.filter(
		func(p: Player): return p.control_scheme == Player.ControlScheme.CPU
	)
	cpu_players.sort_custom(func(p1: Player, p2: Player):
		return p1.position.distance_squared_to(ball.position) < p2.spawn_position.distance_squared_to(ball.position))
	var closest_cpu_to_ball : Player = cpu_players[0]
	if closest_cpu_to_ball.position.distance_squared_to(ball.position) < requester.position.distance_squared_to(ball.position):
		var player_control_scheme:= requester.control_scheme
		requester.control_scheme = Player.ControlScheme.CPU
		requester.set_control_texture()
		closest_cpu_to_ball.control_scheme = player_control_scheme
		closest_cpu_to_ball.set_control_texture()

func on_tackle_freeze_started() -> void:
	set_actors_frozen(true)

# Disabling processing holds every player (and the ball) exactly where they are, animations included.
func set_actors_frozen(frozen: bool) -> void:
	var mode := Node.PROCESS_MODE_DISABLED if frozen else Node.PROCESS_MODE_INHERIT
	for player in squad_home + squad_away:
		player.process_mode = mode
	ball.process_mode = mode

func on_new_down(yard_line_x: float) -> void:
	set_actors_frozen(false)
	# Re-create the original formation, shifted sideways so its center sits on the yard line.
	var half_width := get_formation_half_width() + FIELD_EDGE_PADDING
	var x_range := get_playable_x_range()
	var line_x := clampf(yard_line_x, x_range.x + half_width, x_range.y - half_width)
	var formation_shift := Vector2(line_x - spawns.global_position.x, 0)
	for player in squad_home + squad_away:
		player.reset_for_new_down(formation_shift)
	ball.reset_for_new_down(ball.spawn_position + formation_shift)

func on_play_resumed() -> void:
	for player in squad_home + squad_away:
		player.resume_play()

func get_formation_half_width() -> float:
	var half_width := 0.0
	for spawn: Node2D in spawns.get_children():
		half_width = maxf(half_width, absf(spawn.global_position.x - spawns.global_position.x))
	return half_width

# x range between the two scoring areas, so the ball can never spawn inside one.
func get_playable_x_range() -> Vector2:
	var left_goal := endzone_home if endzone_home.global_position.x < endzone_away.global_position.x else endzone_away
	var right_goal := endzone_away if left_goal == endzone_home else endzone_home
	return Vector2(get_scoring_area_edge(left_goal, 1.0), get_scoring_area_edge(right_goal, -1.0))

func get_scoring_area_edge(goal: Goal, inward: float) -> float:
	var shape_node := goal.scoring_area.get_child(0) as CollisionShape2D
	var half_width := (shape_node.shape as RectangleShape2D).size.x * 0.5
	return shape_node.global_position.x + half_width * inward
