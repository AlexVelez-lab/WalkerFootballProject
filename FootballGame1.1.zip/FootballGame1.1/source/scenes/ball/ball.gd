class_name Ball
extends AnimatableBody2D

const FUMBLE_HEIGHT_VELOCITY := 1.0
const DURATION_FUMBLE_LOCK := 500
const DURATION_PASS_LOCK := 500
const WAIT := 3000

enum State {CARRIED, FREEFORM, SHOT}

@export var friction_air : float
@export var friction_ground : float

@onready var animation_player : AnimationPlayer = %AnimationPlayer
@onready var ball_sprite : Sprite2D = %BallSprite
@onready var player_detection_area : Area2D = %PlayerDetectionArea

var carrier : Player = null
var current_state : BallState = null
var state_factory := BallStateFactory.new()
var velocity := Vector2.ZERO
var height := 0.0
var height_velocity := 0.0
var spawn_position := Vector2.ZERO

func _ready() -> void:
	switch_state(State.FREEFORM)
	spawn_position = position
	GameEvents.team_reset.connect(on_team_reset.bind())
	
func _process(_delta: float) -> void:
	ball_sprite.position = Vector2.UP * height

func switch_state(state: Ball.State, data: BallStateData = BallStateData.new()) -> void:
	if current_state != null:
		current_state.queue_free()
	current_state = state_factory.get_fresh_state(state)
	current_state.setup(self, data, player_detection_area, carrier, animation_player, ball_sprite)
	current_state.state_transition_requested.connect(switch_state.bind())
	current_state.name = "BallStateMachine"
	call_deferred("add_child", current_state)
	
func throw(throw_velocity : Vector2) -> void:
	velocity = throw_velocity
	carrier = null
	switch_state(Ball.State.SHOT)

func fumble(fumble_velocity: Vector2) -> void:
	var yard_line_x := carrier.position.x if carrier != null else position.x
	velocity = fumble_velocity
	carrier = null
	height_velocity = FUMBLE_HEIGHT_VELOCITY
	switch_state(Ball.State.FREEFORM, BallStateData.build().set_lock_duration(DURATION_FUMBLE_LOCK))
	GameEvents.ball_fumbled.emit(yard_line_x)

func pass_to(destination: Vector2) -> void:
	var direction := position.direction_to(destination)
	var distance := position.distance_to(destination)
	var intensity := sqrt(2 * distance * 120)
	velocity = intensity * direction
	carrier = null
	switch_state(Ball.State.FREEFORM, BallStateData.build().set_lock_duration(DURATION_PASS_LOCK))
	
func on_team_reset() -> void:
	position = spawn_position
	velocity = Vector2.ZERO
	switch_state(State.FREEFORM)

func reset_for_new_down(new_position: Vector2) -> void:
	if current_state != null:
		current_state.set_process(false)
	position = new_position
	velocity = Vector2.ZERO
	height = 0.0
	height_velocity = 0.0
	carrier = null
	switch_state(State.FREEFORM)
