extends Node

const DURATION_GAME := 2
const FIRST_DOWN := 1
const MAX_DOWN := 4

enum State {IN_PLAY, SCORED, RESET, KICKOFF, OVERTIME, GAMEOVER, NEW_DOWN}

var countries : Array[String] = ["STEELERS", "RAVENS"]
var current_state : GameState = null
var state_factory := GameStateFactory.new()
var score : Array[int] = [0,0]
var time_left : float
var down := FIRST_DOWN

func _ready() -> void:
	SoundPlayer.play(SoundPlayer.Sound.NFL)
	time_left = DURATION_GAME
	switch_states(State.IN_PLAY)

func switch_states(state: State, data: GameStateData = GameStateData.new()) -> void:
	if current_state != null:
		current_state.queue_free()
	current_state = state_factory.get_fresh_state(state)
	current_state.setup(self, data)
	current_state.state_transition_requested.connect(switch_states.bind())
	current_state.name = "GameStateMachine: " + str(state)
	call_deferred("add_child", current_state)

func is_game_tied() -> bool:
	return score[0] == score[1]
	
func is_time_up() -> bool:
	return time_left <= 0
	
func get_winner_country() -> String:
	assert(not is_game_tied())
	return countries[0] if score[0] > score[1] else countries[1]

func increase_score(country_scored_on: String) -> void:
	var index_country_scoring := 1 if country_scored_on == countries[0] else 0
	score[index_country_scoring] += 1
	GameEvents.score_changed.emit()

func has_someone_scored() -> bool:
	return score[0] > 0 or score[1] > 0

func advance_down() -> void:
	# TODO (turn over): when down is MAX_DOWN, possession should change here
	# and the down should go back to FIRST_DOWN for the other team.
	down = mini(down + 1, MAX_DOWN)
	GameEvents.down_changed.emit()

func reset_down() -> void:
	down = FIRST_DOWN
	GameEvents.down_changed.emit()
