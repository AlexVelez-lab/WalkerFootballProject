class_name GameStateNewDown
extends GameState

# How long everything stays frozen after a tackle (ms).
const DURATION_FREEZE := 1000
# How long the new formation waits on the line before the whistle and resumed play (ms).
const DURATION_HOLD := 1000

enum Phase {FREEZE, HOLD}

var phase := Phase.FREEZE
var time_since_phase_start := Time.get_ticks_msec()

func _enter_tree() -> void:
	time_since_phase_start = Time.get_ticks_msec()
	GameEvents.tackle_freeze_started.emit()

# The game clock is paused during both phases.
func _process(_delta: float) -> void:
	var elapsed := Time.get_ticks_msec() - time_since_phase_start
	match phase:
		Phase.FREEZE:
			if elapsed > DURATION_FREEZE:
				phase = Phase.HOLD
				time_since_phase_start = Time.get_ticks_msec()
				manager.advance_down()
				GameEvents.new_down.emit(state_data.yard_line_x)
		Phase.HOLD:
			if elapsed > DURATION_HOLD:
				SoundPlayer.play(SoundPlayer.Sound.WHISTLE)
				GameEvents.play_resumed.emit()
				transition_state(state_data.return_state)
