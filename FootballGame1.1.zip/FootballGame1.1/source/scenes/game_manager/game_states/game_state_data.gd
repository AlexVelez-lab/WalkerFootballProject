class_name GameStateData

var country_scored_on : String
var yard_line_x : float
var return_state : GameManager.State = GameManager.State.IN_PLAY

static func build() -> GameStateData:
	return GameStateData.new()
	
func set_country_scored_on(country: String) -> GameStateData:
	country_scored_on = country
	return self

func set_yard_line_x(x: float) -> GameStateData:
	yard_line_x = x
	return self

func set_return_state(state: GameManager.State) -> GameStateData:
	return_state = state
	return self
