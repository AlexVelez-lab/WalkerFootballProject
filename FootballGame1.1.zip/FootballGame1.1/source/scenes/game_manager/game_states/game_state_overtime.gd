class_name GameStateOvertime
extends GameState

func _enter_tree() -> void:
	GameEvents.team_scored.connect(on_team_scored.bind())
	GameEvents.ball_fumbled.connect(on_ball_fumbled.bind())
	
func on_team_scored(country_scored_on: String) -> void:
	manager.increase_score(state_data.country_scored_on)
	transition_state(GameManager.State.GAMEOVER)

func on_ball_fumbled(yard_line_x: float) -> void:
	transition_state(GameManager.State.NEW_DOWN, GameStateData.build().set_yard_line_x(yard_line_x).set_return_state(GameManager.State.OVERTIME))
