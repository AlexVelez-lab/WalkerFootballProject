class_name GameStateReset
extends GameState

func _enter_tree() -> void:
	SoundPlayer.play(SoundPlayer.Sound.WHISTLE)
	manager.reset_down()
	GameEvents.team_reset.emit()
	transition_state(GameManager.State.IN_PLAY)
		
